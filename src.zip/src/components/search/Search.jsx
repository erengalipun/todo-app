import React from 'react';
import './Search.scss';

export default function Search( { searchTerm, setSearchTerm }) {

  return(
    <div className='search-container'>
      <input 
          type='search'
          placeholder='Search your task title...'
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
    </div>
  );
}