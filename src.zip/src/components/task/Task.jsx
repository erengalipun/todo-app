import React, { useState } from "react";
import TaskEdit from "./TaskEdit.jsx"

export default function Task({ task, handleDeleteTask, handleCompleteTask, handleEditTask }) {
  const [isEditing, setIsEditing] = useState(false);

  const handleEditClick = () => {
    setIsEditing(true);
  };

  const handleSave = (updatedTasks) => {
    handleEditTask(updatedTasks);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setIsEditing(false);
  };
  
  return(
    <>
      {isEditing ? (
          <TaskEdit tasks={task} onSave={handleSave} onCancel={handleCancel} />
        ) : (
          <div className="task">
            <div>
              <label>Added Date: </label><span>{task.createdDate}</span>
              <label>Title: </label><span className="text">{task.title}</span>
            </div>
            <div>
              <label>Description: </label><span className="text">{task.description}</span>
              <label>Due Date: </label><span>{task.dueDate}</span>
              <label>Priority: </label><span>{task.priority}</span>
              <label>Completion Status: </label><span>{task.isCompleted ? 'Competed' : 'Not Completed'}</span>
            </div>
            <div>
              <button onClick={() => handleCompleteTask(task.id)}>{task.isCompleted ? 'Undo' : 'Done'}</button>
              <button onClick={() => handleDeleteTask(task.id)}>Delete</button>
              <button onClick={handleEditClick}>Edit</button>
            </div>
          </div>
      )}
    </>
  );
}